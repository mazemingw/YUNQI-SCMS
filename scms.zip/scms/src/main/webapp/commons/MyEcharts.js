$(function(){

 
            
	  
	  
	  
      
	  
	  
	  


	
	   

	
       



        
       
       
       
       
        
        //window.onresize=myChart1.resize;
})
           
                   