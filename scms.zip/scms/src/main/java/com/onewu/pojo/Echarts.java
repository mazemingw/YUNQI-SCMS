package com.onewu.pojo;

public class Echarts {
	// 图列名称
	private String name ;
	// 图列值
	private int value ;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	
}
