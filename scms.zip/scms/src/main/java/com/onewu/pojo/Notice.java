package com.onewu.pojo;

public class Notice {
	private String id;
	private String userId;
	private String content;
	private String title;
	private String operatetime;
	private int type;
	private String typeName;
	private String noticebelong;
	private String flag;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getOperatetime() {
		return operatetime;
	}
	public void setOperatetime(String operatetime) {
		this.operatetime = operatetime;
	}
	public String getTypeName() {
		return typeName;
	}
	public String getNoticebelong() {
		return noticebelong;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public void setNoticebelong(String noticebelong) {
		this.noticebelong = noticebelong;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	
}
